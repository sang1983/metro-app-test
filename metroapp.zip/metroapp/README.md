# Your First Web Application with Spring Boot
Develop your first web application with Spring Boot in more than 25 steps
* [Installing Eclipse, Maven and Java](#installing-tools)
* [Course Overview](#course-overview)
* [About in28Minutes](#about-in28minutes)
  - [Our Beliefs](#our-beliefs)
  - [Our Approach](#our-approach)
  - [Find Us](#useful-links)
  - [Other Courses](#other-courses)

## Installing Tools
- PDF : https://github.com/in28minutes/SpringIn28Minutes/blob/master/InstallationGuide-JavaEclipseAndMaven_v2.pdf
- Video : https://www.youtube.com/playlist?list=PLBBog2r6uMCSmMVTW_QmDLyASBvovyAO3
- GIT Repository : https://github.com/in28minutes/getting-started-in-5-steps

## Course Overview

### Introduction
Developing your first Spring Boot Web Application is fun.

Spring Boot makes it easy to create stand-alone, production-grade Spring based Applications that you can “just run”. We take an opinionated view of the Spring platform and third-party libraries so you can get started with minimum fuss. Most Spring Boot applications need very little Spring configuration.

In this course, you will learn the basics developing a Basic Store Management Application using Spring Boot with Login and Logout functionalities.

You will build the website step by step - in more than 25 steps. This course would be a perfect first step as an introduction to Java Web Application Development.

You will be using Spring (Dependency Management), Spring MVC, Spring Boot, Spring Security (Authentication and Authorization), BootStrap (Styling Pages), Maven (dependencies management), Eclipse (IDE) and Tomcat Embedded Web Server. We will help you set up each one of these.

You will learn about
- Basics of Spring Boot
- Basics of Autoconfiguration and Spring Boot Magic
- DispatcherServlet
- Basic Store Management Application with Login/Logout
- Model, Controllers, ViewResolver and Filters
- Forms - DataBinding, Validation
- Annotation based approach - @RequestParam, @ModelAttribute, @SessionAttributes etc
- Bootstrap to style the page
- Spring Security
- Exception Handling

### Step Wise Details
- Step 01: Basic Spring Boot Web Application Setup
- Step 02: First Spring MVC Controller, @ResponseBody, @Controller
- Step 03: Demystifying some of the Spring Boot magic
- Step 04: Redirect to Login JSP - LoginController, @ResponseBody and View Resolver
- Step 05: Show userid and password on the welcome page - ModelMap and @RequestParam
- Step 06: DispatcherServlet and Spring MVC Flow
- Step 07: Your First HTML form
- Step 08: Add hard-coded validation of userid and password
- Step 09: Magic of Spring
- Step 10: Create StoreController and list-stores view. Make StoreService a @Service and inject it.
- Step 11: Architecture of Web Applications
- Step 12: Session vs Model vs Request - @SessionAttributes
- Step 13: Add new store
- Step 14: Display Stores in a table using JSTL Tags
- Step 15: Bootstrap for Page Formatting using webjars
- Step 16: Let's delete a Store
- Step 17: Format Add Store Page and Adding Basic HTML5 form validation
- Step 18: Introduce JSR 349 Validations using Hibernate Validator - First Command Bean.
- Step 19: Updating a store
- Step 20: Let's add a Target Date for Store - Use initBinder to Handle Date Fields
- Step 21: JSP Fragments and Navigation Bar
- Step 22: Preparing for Spring Security
- Step 23: Initial Spring Security Setup
- Step 24: Refactor and add Logout Functionality using Spring Security
- Step 25: Exception Handling

---

- We do NOT interact with a Database in this Beginner’s Course.
- We will be building a traditional JSP based web application in this course. 

---

### Expectations
- You should know Java. You should understand usage of Annotations.
- You should understand the basics of Spring framework.
- You are NOT expected to have any experience with Eclipse or Maven.
- We will help you install Eclipse and get up and running with Maven.

## Let's have some fun
- What are we waiting for?
- Let's have some fun building a web application Spring Boot in 25 Steps.
- I had fun creating this course and hope you would too.
- Thanks for your interest in Our Course 
  - I hope you’re as excited as I am!  
  - If you’re ready to learn more and sign up for the course, 
  - go ahead and hit that Enroll button, 
  - or take a test drive by using the Free Preview feature.  
- See you in the course!

## Getting Started
- Eclipse - https://courses.in28minutes.com/p/eclipse-tutorial-for-beginners
- Maven - https://courses.in28minutes.com/p/maven-tutorial-for-beginners-in-5-steps
- JUnit - https://courses.in28minutes.com/p/junit-tutorial-for-beginners
- Mockito - https://courses.in28minutes.com/p/mockito-for-beginner-in-5-steps

## About in28Minutes
- At in28Minutes, we ask ourselves one question everyday. How do we help you learn effectively - that is more quickly and retain more of what you have learnt?
- We use Problem-Solution based Step-By-Step Hands-on Approach With Practical, Real World Application Examples. 
- Our success on Udemy and Youtube (2 Million Views & 12K Subscribers) speaks volumes about the success of our approach.
- While our primary expertise is on Development, Design & Architecture Java & Related Frameworks (Spring, Struts, Hibernate) we are expanding into the front-end world (Bootstrap, JQuery, Angular JS). 

### Our Beliefs
- Best Courses are interactive and fun.
- Foundations for building high quality applications are best laid down while learning.

### Our Approach
- Problem Solution based Step by Step Hands-on Learning
- Practical, Real World Application Examples.
- We use 80-20 Rule. We discuss 20% things used 80% of time in depth. We touch upon other things briefly equipping you with enough knowledge to find out more on your own. 
- We will be developing a demo application in the course, which could be reused in your projects, saving hours of your effort.
- We love open source and therefore, All our code is open source too and available on Github.

### Other Courses

- [Check out all our courses with 100,000 Students](https://courses.in28minutes.com/courses)
- [25 Videos and Articles for Beginners on Spring Boot](http://www.springboottutorial.com/spring-boot-tutorials-for-beginners)
- Our Best Courses with 66,000 Students and 4,000 5-Star Ratings
  * [Java Interview Guide : 200+ Interview Questions and Answers](https://www.udemy.com/java-interview-questions-and-answers/?couponCode=JAVA_INTER_GIT)
  * [Mockito Tutorial : Learn mocking with 25 Junit Examples](https://www.udemy.com/mockito-tutorial-with-junit-examples/?couponCode=MOCKITO_GIT)
  * [Java EE Made Easy - Patterns, Architecture and Frameworks](https://www.udemy.com/java-ee-design-patterns-architecture-and-frameworks/?couponCode=EEPATTERNS-GIT)
  * [Spring MVC For Beginners : Build Java Web App in 25 Steps](https://www.udemy.com/spring-mvc-tutorial-for-beginners-step-by-step/?couponCode=SPRINGMVC-GIT)
  * [JSP Servlets For Beginners : Build Java Web App in 25 Steps](https://www.udemy.com/learn-java-servlets-and-jsp-web-application-in-25-steps/?couponCode=JSPSRVLT-GIT)
  * [Maven Tutorial - Manage Java Dependencies in 25 Steps](https://www.udemy.com/learn-maven-java-dependency-management-in-20-steps/?couponCode=MAVEN_GIT)
  * [Java OOPS in 1 Hours](https://www.udemy.com/learn-object-oriented-programming-in-java/?couponCode=OOPS-GIT)
  * [C Puzzle for Interview](https://www.udemy.com/c-puzzles-for-beginners/?couponCode=CPUZZLES-GIT)
  
### Useful Links
- [Our Website](http://www.in28minutes.com)
- [Facebook](http://facebook.com/in28minutes)
- [Twitter](http://twitter.com/in28minutes)
- [Google Plus](https://plus.google.com/u/3/110861829188024231119)
